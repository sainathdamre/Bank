// Store loan application in local storage (acting as cache)
function storeLoanDetails(loanDetails) {
    // Get existing loan details from localStorage, or initialize an empty array if not present
    let loanRequests = JSON.parse(localStorage.getItem('loanRequests')) || [];

    // Check if the SSN ID already exists
    const existingLoan = loanRequests.find(request => request.ssn_id === loanDetails.ssn_id);
    
    if (existingLoan) {
        // If SSN ID exists, alert the user
        alert("Loan request already exists for this SSN ID!");
        return false; // Prevent adding the duplicate request
    }

    // Add the new loan details to the array
    loanRequests.push(loanDetails);
    // Store the updated loan details array back in localStorage
    localStorage.setItem('loanRequests', JSON.stringify(loanRequests));

    return true; // Indicate that the loan details have been successfully stored
}

// Validate and Submit the Loan Form
function validateForm(event) {
    event.preventDefault(); // Prevent form submission

    const ssnId = document.getElementById('ssn-id').value;
    const customerName = document.getElementById('customer-name').value;
    const occupation = document.getElementById('occupation').value;
    const employerName = document.getElementById('employer-name').value;
    const contactNumber = document.getElementById('contact-number').value;
    const loanAmount = document.getElementById('loan-amount').value;
    const loanDuration = document.getElementById('loan-duration').value;
    const addressC = document.getElementById('customer-address').value;
    const addressE = document.getElementById('employer-address').value;
    const email = document.getElementById('email').value;

    // SSN ID validation
    if (ssnId.length !== 6 || isNaN(ssnId)) {
        alert("Customer SSN ID must be exactly 6 numeric digits.");
        return false;
    }

    // Customer name validation
    if (customerName.length < 3) {
        alert("Customer name must be at least 3 characters.");
        return false;
    }

    if (occupation.length < 3) {
        alert("Occupation must be at least 3 characters.");
        return false;
    }

    if (employerName.length < 3) {
        alert("Employee name must be at least 3 characters.");
        return false;
    }

   

 

    // Address validation (must be at least 3 characters)
    if (addressC.length < 3 || addressE.length < 3) {
        alert("Address must be at least 3 characters long.");
        return false;
    }

    // Email validation (must be in @gmail.com format)
    const emailPattern = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!emailPattern.test(email)) {
        alert("Email must be in the format example@gmail.com.");
        return false;
    }

    // Contact number validation
    if (contactNumber.length !== 10 || isNaN(contactNumber)) {
        alert("Contact number must be exactly 10 digits.");
        return false;
    }
    // Check for repeated digits (3 or more continuous)
    if (/(\d)\1{2,}/.test(contactNumber)) {
        alert("Contact number cannot contain the same digit more than 3 times consecutively.");
        return false;
    }

    // Loan amount validation (must be greater than 1000)
    if (loanAmount <= 1000) {
        alert("Loan amount must be greater than ₹1000.");
        return false;
    }

    // Loan duration validation (must be between 1 and 10 years)
    if (loanDuration < 1 || loanDuration > 10) {
        alert("Loan duration must be between 1 and 10 years.");
        return false;
    }

    // Create loan details object
    const loanDetails = {
        ssn_id: ssnId,
        customer_name: customerName,
        employer_name: employerName,
        contact_number: contactNumber,
        loan_amount: loanAmount,
        loan_duration: loanDuration,
        customer_address: addressC,
        employer_address: addressE,
        email: email
    };

    // Attempt to store the loan details
    const success = storeLoanDetails(loanDetails);

    if (success) {
        alert("Loan request successfully submitted!");
        document.getElementById('loan-form').reset();  // Clear the form after submission (optional)
    }
}
