// Fetch customer details
document.getElementById("fetchButton").addEventListener("click", function () {
    const ssn = document.getElementById("fetchSSN").value;
    const customers = JSON.parse(localStorage.getItem("customers")) || [];
    const customer = customers.find(c => c.ssn === ssn);

    if (!customer) {
        alert("Customer not found!");
        return;
    }

    // Populate form with customer data
    document.getElementById("customerName").value = customer.name;
    document.getElementById("accountNumber").value = customer.accountNumber;
    document.getElementById("ifscCode").value = customer.ifscCode;
    document.getElementById("accountBalance").value = customer.accountBalance;
    document.getElementById("email").value = customer.email;
    document.getElementById("address").value = customer.address;
    document.getElementById("contactNumber").value = customer.contactNumber;

    document.getElementById("customerDetails").style.display = "block";
});

// Update customer details
document.getElementById("updateCustomerForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const ssn = document.getElementById("fetchSSN").value;
    const customers = JSON.parse(localStorage.getItem("customers")) || [];
    const index = customers.findIndex(c => c.ssn === ssn);

    if (index !== -1) {
        customers[index] = {
            ssn,
            name: document.getElementById("customerName").value,
            accountNumber: document.getElementById("accountNumber").value,
            ifscCode: document.getElementById("ifscCode").value,
            accountBalance: document.getElementById("accountBalance").value,
            email: document.getElementById("email").value,
            address: document.getElementById("address").value,
            contactNumber: document.getElementById("contactNumber").value
        };

        localStorage.setItem("customers", JSON.stringify(customers));
        alert("Customer details updated successfully!");
    }
});
