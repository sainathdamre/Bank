// Script for mobile menu toggle (if needed for future extensions)
function toggleMenu() {
    const navbarLinks = document.querySelector('.navbar-links');
    navbarLinks.classList.toggle('active');
}



let slideIndex = 0;

function showSlides() {
    let slides = document.getElementsByClassName("mySlides");

    // Hide all slides initially
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
        slides[i].style.opacity = "0";  // Ensure opacity starts at 0
    }

    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1; }

    slides[slideIndex - 1].style.display = "block";  // Show the current slide
    setTimeout(() => {
        slides[slideIndex - 1].style.opacity = "1";  // Fade in the current slide
    }, 50); // Delay slightly to allow transition to start

    setTimeout(showSlides, 3000); // Change slide every 3 seconds
}

showSlides(); // Start the slideshow
