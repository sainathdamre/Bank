// Fetch loan details based on SSN and display them
document.getElementById('fetch-loan-btn').addEventListener('click', function () {
    const ssnInput = document.getElementById('ssn').value;

    if (!ssnInput) {
        alert("Please enter an SSN ID.");
        return;
    }

    // Fetch the loan details from localStorage
    const loanRequests = JSON.parse(localStorage.getItem('loanRequests')) || [];

    // Find the loan request by SSN ID
    const loanDetails = loanRequests.find(request => request.ssn_id === ssnInput);

    if (loanDetails) {
        // Display the loan details in the form
        document.getElementById('name').value = loanDetails.customer_name;
        document.getElementById('loan-amount').value = loanDetails.loan_amount;
        document.getElementById('loan-duration').value = loanDetails.loan_duration;

        // Show the loan details form
        document.getElementById('update-loan-form').style.display = 'block';
    } else {
        alert("Loan details not found for this SSN ID.");
    }
});

// Submit the updated loan details with validation
document.getElementById('update-loan-form').addEventListener('submit', function (event) {
    event.preventDefault();

    const ssn = document.getElementById('ssn').value;
    const name = document.getElementById('name').value;
    const loanAmount = document.getElementById('loan-amount').value;
    const loanDuration = document.getElementById('loan-duration').value;

    // Validation checks
    if (!name || name.length < 3) {
        alert("Name must be at least 3 characters long.");
        return;
    }

    if (isNaN(loanAmount) || loanAmount <= 1000) {
        alert("Loan amount must be greater than ₹1000.");
        return;
    }

    if (isNaN(loanDuration) || loanDuration <= 0 || loanDuration > 10) {
        alert("Loan duration must be between 1 and 10 years.");
        return;
    }

    // Fetch all the loan requests from localStorage
    let loanRequests = JSON.parse(localStorage.getItem('loanRequests')) || [];

    // Find the loan request by SSN ID and update it
    const loanIndex = loanRequests.findIndex(request => request.ssn_id === ssn);
    if (loanIndex !== -1) {
        loanRequests[loanIndex] = {
            ssn_id: ssn,
            customer_name: name,
            loan_amount: loanAmount,
            loan_duration: loanDuration
        };

        // Save the updated loan requests back to localStorage
        localStorage.setItem('loanRequests', JSON.stringify(loanRequests));

        alert("Loan details updated successfully!");
        window.location.reload();
    } else {
        alert("Loan details not found for this SSN ID.");
    }
});
