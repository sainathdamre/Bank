// Display all customer records
function loadCustomers() {
    const customers = JSON.parse(localStorage.getItem("customers")) || [];
    const tableBody = document.getElementById("customerTableBody");  // Make sure the ID matches
    tableBody.innerHTML = "";

    if (customers.length === 0) {
        const row = `
            <tr>
                <td colspan="5" style="text-align: center;">No customers found</td>
            </tr>
        `;
        tableBody.innerHTML = row;
        return;
    }

    customers.forEach((customer, index) => {
        const row = `
            <tr>
                <td>${customer.ssn}</td>
                <td>${customer.name}</td>
                <td>${customer.accountNumber}</td>
                <td>${customer.contactNumber}</td>
                <td><button onclick="deleteCustomer(${index})">Delete</button></td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

// Delete a customer with confirmation
function deleteCustomer(index) {
    const customers = JSON.parse(localStorage.getItem("customers")) || [];

    // Confirm if the user wants to delete the customer
    const confirmation = confirm("Are you sure you want to delete this customer?");
    
    if (confirmation) {
        // Proceed with deletion if confirmed
        customers.splice(index, 1);
        localStorage.setItem("customers", JSON.stringify(customers));
        loadCustomers();
    }
}

// Load customers on page load
window.onload = loadCustomers;
