﻿// Function to generate random Employee ID
function generateRandomId() {
    return Math.floor(Math.random() * 900000) + 100000; // 6-digit random ID
}

// Pre-fill Employee ID and set placeholder for Password on page load
window.onload = function () {
    const employeeIdField = document.getElementById("employeeId");
    const passwordField = document.getElementById("password");

    // Retrieve cached data
    const cachedId = localStorage.getItem("employeeId");
    const cachedPassword = localStorage.getItem("password");

    if (cachedId && cachedPassword) {
        employeeIdField.value = cachedId;
        passwordField.placeholder = "Enter Password";
    } else {
        employeeIdField.value = generateRandomId();
        passwordField.placeholder = "Enter Password";
    }
};

// Handle Login Form Submission
document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent form submission

    const enteredPassword = document.getElementById("password").value;
    const cachedPassword = localStorage.getItem("password");

    // Check if the password matches the registered password
    if (enteredPassword.trim() === cachedPassword) {
        alert("✅ Login Successful!");
        window.location.href = "services.html"; // Redirect to services page
    } else {
        alert("❌ Invalid Password! Please try again.");
    }
});

// Function to save registration details
function saveRegistrationDetails(id, password) {
    localStorage.setItem("employeeId", id);
    localStorage.setItem("password", password);
}
