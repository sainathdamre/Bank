document.getElementById("customer_form").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    const customers = JSON.parse(localStorage.getItem("customers")) || [];

    // Validate SSN
    const ssn = document.getElementById("customerSSN").value;
    if (!/^\d{6}$/.test(ssn)) {
        alert("SSN ID must be exactly 6 digits.");
        return;
    }
    if (customers.some(customer => customer.ssn === ssn)) {
        alert("SSN ID already exists. Please enter a unique SSN.");
        return;
    }

    // Validate Customer Name (should be more than 3 characters)
    const customerName = document.getElementById("customerName").value;
    if (!/^[A-Za-z\s]+$/.test(customerName) || customerName.length <= 3) {
        alert("Customer Name must contain only alphabetic characters, spaces, and be more than 3 characters long.");
        return;
    }

    // Validate Account Number
    const accountNumber = document.getElementById("accountNumber").value;
    if (!/^\d{1,12}$/.test(accountNumber) || accountNumber.length > 12) {
        alert("Account Number must be a numeric value and not exceed 12 digits.");
        return;
    }
    if (customers.some(customer => customer.accountNumber === accountNumber)) {
        alert("Account Number already exists. Please enter a unique account number.");
        return;
    }

    // Validate IFSC Code (correct length 11 characters: 4 alphabets + 7 digits)
    const ifscCode = document.getElementById("ifscCode").value;
    if (!/^[A-Za-z]{4}\d{6}$/.test(ifscCode)) {
        alert("IFSC Code must follow the format: 4 alphabetic characters followed by 7 digits.");
        return;
    }
    if (customers.some(customer => customer.ifscCode === ifscCode)) {
        alert("IFSC Code already exists. Please enter a unique IFSC code.");
        return;
    }

    // Validate Account Balance
    const accountBalance = document.getElementById("accountBalance").value;
    if (accountBalance < 500) {
        alert("Account Balance must be more than 500.");
        return;
    }

    // Validate Aadhaar Number
    const aadhaarNumber = document.getElementById("aadhaarNumber").value;
    if (aadhaarNumber.length !== 12 || !/^\d{12}$/.test(aadhaarNumber)) {
        alert("Aadhaar Number must be exactly 12 digits.");
        return;
    }
    if (customers.some(customer => customer.aadhaarNumber === aadhaarNumber)) {
        alert("Aadhaar Number already exists. Please enter a unique Aadhaar number.");
        return;
    }

    // Validate PAN Card Number
    const panCard = document.getElementById("panCard").value;
    if (panCard.length !== 10 || !/^[A-Za-z]{5}\d{4}[A-Za-z]{1}$/.test(panCard)) {
        alert("PAN Card Number must be exactly 10 characters and follow the format: 5 alphabets, 4 digits, 1 alphabet.");
        return;
    }
    if (customers.some(customer => customer.panCard === panCard)) {
        alert("PAN Card Number already exists. Please enter a unique PAN Card number.");
        return;
    }

    const dob = document.getElementById("dob").value;
    if (!dob) {
        alert("Date of Birth is required. Please enter your date of birth.");
        return;
    }

    // Validate Gender
    const gender = document.getElementById("gender").value;
    if (!gender) {
        alert("Gender is required. Please select your gender.");
        return;
    }

    // Validate Marital Status
    const maritalStatus = document.getElementById("maritalStatus").value;
    if (!maritalStatus) {
        alert("Marital Status is required. Please select your marital status.");
        return;
    }

    // Validate Email
    const email = document.getElementById("email").value;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !email.endsWith("@gmail.com")) {
        alert("Email must be in the format user@gmail.com.");
        return;
    }

    // Validate Address
    const address = document.getElementById("address").value;
    if (address.length < 5) {
        alert("Address must be at least 5 characters long.");
        return;
    }

    // Validate Contact Number
    const contact = document.getElementById("contactNumber").value;
    if (!/^\d{10}$/.test(contact)) {
        alert("Contact Number must be exactly 10 digits.");
        return;
    }
    if (/(\d)\1{3,}/.test(contact)) {
        alert("Contact Number cannot have any digit repeated more than 3 times consecutively.");
        return;
    }

    // Save data if all validations pass
    customers.push({
        ssn,
        name: customerName,
        accountNumber,
        ifscCode,
        accountBalance,
        aadhaarNumber,
        panCard,
        dob,
        gender,
        maritalStatus,
        email,
        address,
        contactNumber: contact
    });
    localStorage.setItem("customers", JSON.stringify(customers));

    alert("Registration successful!");
    document.getElementById("customer_form").reset();
});
