// Function to load loan requests from localStorage and display them in a table
function loadLoanRequests() {
    const loanRequestsContainer = document.getElementById('loan-requests-container');
    
    // Retrieve loan requests from localStorage
    const loanRequests = JSON.parse(localStorage.getItem('loanRequests')) || [];
    
    if (loanRequests.length > 0) {
        let tableHTML = `
            <table>
                <tr>
                    <th>SSN ID</th>
                    <th>Customer Name</th>
                    <th>Loan Amount (₹)</th>
                    <th>Loan Duration (Years)</th>
                    <th>Action</th>
                </tr>
        `;
        
        loanRequests.forEach((loan, index) => {
            tableHTML += `
                <tr>
                    <td>${loan.ssn_id}</td>
                    <td>${loan.customer_name}</td>
                    <td>${loan.loan_amount}</td>
                    <td>${loan.loan_duration}</td>
                    <td><button class="cancel-btn" onclick="cancelLoan(${index})">Cancel Loan</button></td>
                </tr>
            `;
        });

        tableHTML += `</table>`;
        loanRequestsContainer.innerHTML = tableHTML;
    } else {
        loanRequestsContainer.innerHTML = "<p>No loan requests found.</p>";
    }
}

// Function to handle loan cancellation
function cancelLoan(index) {
    // Confirm cancellation before proceeding
    const confirmCancel = confirm("Are you sure you want to cancel this loan?");
    
    if (confirmCancel) {
        // Retrieve the loan requests from localStorage
        const loanRequests = JSON.parse(localStorage.getItem('loanRequests')) || [];
        
        // Remove the loan from the list (or localStorage if applicable)
        loanRequests.splice(index, 1); // Remove the loan record
        
        // Update the loan requests in localStorage
        localStorage.setItem('loanRequests', JSON.stringify(loanRequests));
        
        alert("Loan request has been canceled.");
        
        // Reload the updated list of loan requests
        loadLoanRequests();
    }
}

// Load the loan requests when the page is loaded
window.onload = loadLoanRequests;
