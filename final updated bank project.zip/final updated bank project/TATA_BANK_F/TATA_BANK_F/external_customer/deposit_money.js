// Auto-populate SSN ID from localStorage
window.onload = function () {
  const ssnField = document.getElementById("ssn-id");

  // Fetch SSN ID from localStorage
  const ssnId = localStorage.getItem("customerId");

  if (ssnId) {
      ssnField.value = ssnId; // Auto-fill the SSN ID
  } else {
      alert("SSN ID not found. Please login first.");
      window.location.href = "external_customer_registeration.html"; // Redirect to login page
  }
};

// Mock data for account balances
const accountBalances = {
  "1234567890": 5000,
  "9876543210": 10000,
  "5555555555": 75000,
};

// Handle form submission
document.getElementById("depositForm").addEventListener("submit", function (event) {
  event.preventDefault();

  // Get input values
  const ssnId = document.getElementById("ssn-id").value;
  const accountNumber = document.getElementById("accountNumber").value;
  const depositAmount = parseFloat(document.getElementById("depositAmount").value);

  // Check if account exists
  if (accountBalances[accountNumber] !== undefined) {
      // Update balance
      const oldBalance = accountBalances[accountNumber];
      accountBalances[accountNumber] += depositAmount;

      // Display updated details
      document.getElementById("ssn").textContent = ssnId;
      document.getElementById("accountDetailsNumber").textContent = accountNumber;
      document.getElementById("oldB").textContent = oldBalance;
      document.getElementById("accountBalance").textContent = accountBalances[accountNumber].toFixed(2);

      // Show details section
      document.getElementById("details-view").classList.remove("hidden");
  } else {
      alert("Account number not found!");
  }
});
