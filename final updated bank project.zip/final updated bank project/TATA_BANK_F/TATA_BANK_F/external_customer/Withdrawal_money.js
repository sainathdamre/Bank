
// Auto-populate SSN ID from localStorage
window.onload = function () {
  const ssnField = document.getElementById("ssn-id");

  // Fetch SSN ID from localStorage
  const ssnId = localStorage.getItem("customerId");

  if (ssnId) {
      ssnField.value = ssnId; // Auto-fill the SSN ID
  } else {
      alert("SSN ID not found. Please login first.");
      window.location.href = "external_customer_registeration.html"; // Redirect to login page
  }
};

// Mock data for account balances
const accountBalances = {
  "1234567890": 5000,
  "9876543210": 10000,
  "1234567890": 99999,
  "9899899999": 78999
};

// Handle form submission
document.getElementById('withdrawalForm').addEventListener('submit', function(event) {
  event.preventDefault();


 const ssnId = document.getElementById('ssn-id').value;
  if (ssnId.length > 10) {
        alert("SSN ID cannot be more than 10 characters.");
        return false;
    }
  // Get input values
  const accountNumber = document.getElementById('accountNumber').value;
  const withdrawalAmount = parseFloat(document.getElementById('withdrawalAmount').value);

  // Check if account exists
  if (accountBalances[accountNumber] !== undefined) {
    // Update balance
    const oldBalance=accountBalances[accountNumber];
    accountBalances[accountNumber] -= withdrawalAmount;

    // Display updated details

    document.getElementById('ssn').textContent=ssnId;
    document.getElementById('accountDetailsNumber').textContent = accountNumber;
    document.getElementById('oldB').textContent = oldBalance;
    document.getElementById('accountBalance').textContent = accountBalances[accountNumber].toFixed(2);

    // Show details section
    document.getElementById('details').style.display = 'block';
  } else {
    alert("Account number not found!");
  }
});