﻿window.onload = function () {
    const customerIdField = document.getElementById("employeeId");

    // Fetch Customer ID from localStorage
    const customerId = localStorage.getItem("customerId");

    if (customerId) {
        customerIdField.value = customerId; // Auto-fill the Customer ID
    } else {
        alert("Customer ID not found. Please register first.");
        window.location.href = "external_customer_registeration.html"; // Redirect to registration
    }
};

document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const password = document.getElementById("password").value;

    const storedPassword = localStorage.getItem("password");

    if (password === storedPassword) {
        alert("✅ Login Successful!");
        window.location.href = "external_customer_services.html"; // Redirect to services page after successful login
    } else {
        alert("❌ Incorrect Password!");
    }
});
