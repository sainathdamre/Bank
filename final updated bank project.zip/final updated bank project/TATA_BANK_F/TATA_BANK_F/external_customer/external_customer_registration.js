function validateForm() {
    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    // Validate First and Last Name
    if (firstName.length < 3 || lastName.length < 3) {
        alert("First and Last Name must contain at least 3 characters.");
        return false;
    }

    // Validate Email
    const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!emailRegex.test(email)) {
        alert("Please use a valid Gmail address.");
        return false;
    }

    // Validate Password
    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return false;
    }

    // Store Data in Local Storage
    const customerId = generateRandomId();
    localStorage.setItem("customerId", customerId);
    localStorage.setItem("password", password);

    // Show Acknowledgment Section
    document.getElementById("registrationSection").style.display = "none";
    document.getElementById("acknowledgmentSection").style.display = "block";

    // Fill Acknowledgment Details
    document.getElementById("customerId").textContent = customerId;
    document.getElementById("fullName").textContent = `${firstName} ${lastName}`;
    document.getElementById("userEmail").textContent = email;

    return false; // Prevent form submission
}

// Generate Random Customer ID
function generateRandomId() {
    return Math.floor(Math.random() * 900000) + 100000; // 6-digit ID
}

// Redirect to Login Page
function redirectToLogin() {
    window.location.href = "external_customer_login.html";
}

// Redirect to Login Page from Registration
function redirectToLoginFromRegistration() {
    window.location.href = "external_customer_login.html";
}
