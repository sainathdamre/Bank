function validateForm() {
    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const address = document.getElementById("address").value.trim();
    const contactNumber = document.getElementById("contactNumber").value.trim();

    // Validate First and Last Name
    if (firstName.length < 3 || lastName.length < 3) {
        alert("First and Last Name must contain at least 3 characters.");
        return false;
    }


    if (address.length < 3) {
        alert("Address must contain at least 3 characters.");
        return false;
    }

    // Validate Email
    const emailRegex = /^[a-zA-Z0-9._%+-]+@tcs\.com$/;
    if (!emailRegex.test(email)) {
        alert("Please use a valid TCS email.");
        return false;
    }

    // Validate Password
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(password)) {
        alert("Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one number.");
        return false;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return false;
    }

    // Validate Contact Number
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(contactNumber)) {
        alert("Contact number must be 10 digits.");
        return false;
    }

    // Check for repetitive continuous numbers (e.g., 1234, 1111)
    const repetitiveNumbersRegex = /(0000|1111|2222|3333|4444|5555|6666|7777|8888|9999)/;
    if (repetitiveNumbersRegex.test(contactNumber)) {
        alert("Contact number should not have repetitive continuous digits.");
        return false;
    }

    // Store Data in Local Storage
    const employeeId = generateRandomId();
    localStorage.setItem("employeeId", employeeId);
    localStorage.setItem("password", password);

    // Show Acknowledgment Section
    document.getElementById("registrationSection").style.display = "none";
    document.getElementById("acknowledgmentSection").style.display = "block";

    // Fill Acknowledgment Details
    document.getElementById("employeeId").textContent = employeeId;
    document.getElementById("fullName").textContent = `${firstName} ${lastName}`;
    document.getElementById("userEmail").textContent = email;

    return false; // Prevent form submission
}

// Generate Random Employee ID
function generateRandomId() {
    return Math.floor(Math.random() * 900000) + 100000; // 6-digit ID
}

function redirectToLogin() {
    window.location.href = "login.html";
}
